////  Chrome preload section

//var visibilityRecorded = false;

//function wa_vchangeFromPrerender(e) {

//    //  see if a pre-rendering page is now visible - this section measures when a page goes from hidden to visible
//    if (!visibilityRecorded) {
//        visibilityRecorded = true;
//        var vimg = new Image(), ttz = new Date();
//        vimg.src = 'http://loc1.hitsprocessor.com/track-visibility.aspx?state=x-ptv&tks=' + ttz.getTime() + '&u=' + encodeURIComponent(document.URL);
//    }    
//}

//function wa_vchangeFromHidden(e) {

//    //  see if a pre-rendering page is now visible - this section measures when a page goes from hidden to visible
//    if (!visibilityRecorded) {
//        visibilityRecorded = true;
//        var vimg = new Image(), ttz = new Date();
//        vimg.src = 'http://loc1.hitsprocessor.com/track-visibility.aspx?state=x-htv&tks=' + ttz.getTime() + '&u=' + encodeURIComponent(document.URL);
//    }
//}

//if (localStorage.installDate == undefined) {
//    localStorage.installDate = new Date();
//}

////  see if Chrome is pre-rendering pages 
//if (new Date(localStorage.installDate) > new Date(2012, 1, 6)) {
//    if (document.webkitVisibilityState == 'prerender') {
//        document.addEventListener('webkitvisibilitychange', wa_vchangeFromPrerender, false);
//    }

//    if (document.webkitVisibilityState == 'hidden') {
//        document.addEventListener('webkitvisibilitychange', wa_vchangeFromHidden, false);
//    }

//    var vimg = new Image(), ttz = new Date();
//    vimg.src = 'http://loc1.hitsprocessor.com/track-visibility.aspx?state=x-' + document.webkitVisibilityState + '&tks=' + ttz.getTime() + '&u=' + encodeURIComponent(document.URL);
//}


